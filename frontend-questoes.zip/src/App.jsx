import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster, toast } from 'react-hot-toast';
import axios from 'axios';

const API_BASE = 'https://backend-questoes.onrender.com';

function Login({ setToken }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    try {
      const res = await axios.post(`${API_BASE}/auth/login`, { email, password });
      setToken(res.data.token);
      localStorage.setItem('token', res.data.token);
      toast.success('Login realizado');
    } catch {
      toast.error('Credenciais inválidas');
    }
  };

  return (
    <div className='p-4 max-w-md mx-auto mt-20 shadow-xl rounded-xl bg-white'>
      <h2 className='text-2xl font-bold mb-4'>Login</h2>
      <input className='border p-2 w-full mb-2' placeholder='Email' onChange={e => setEmail(e.target.value)} />
      <input className='border p-2 w-full mb-4' type='password' placeholder='Senha' onChange={e => setPassword(e.target.value)} />
      <button onClick={handleLogin} className='bg-blue-500 text-white p-2 w-full rounded'>Entrar</button>
    </div>
  );
}

function Questoes() {
  const [questoes, setQuestoes] = useState([]);
  const [respostas, setRespostas] = useState({});
  const token = localStorage.getItem('token');

  useEffect(() => {
    axios.get(`${API_BASE}/questions`, {
      headers: { Authorization: `Bearer ${token}` }
    })
    .then(res => setQuestoes(res.data))
    .catch(() => toast.error("Erro ao carregar questões"));
  }, [token]);

  const responder = (id, resposta) => {
    axios.post(`${API_BASE}/questions/${id}/answer`, {
      resposta_usuario: resposta,
      tempo_resposta: 10
    }, {
      headers: { Authorization: `Bearer ${token}` }
    })
    .then(res => {
      toast.success(res.data.correta ? "Certa!" : "Errada");
      setRespostas({ ...respostas, [id]: resposta });
    })
    .catch(() => toast.error("Erro ao enviar resposta"));
  };

  return (
    <div className='p-4'>
      <h2 className='text-xl font-bold mb-4'>Questões</h2>
      {questoes.map(q => (
        <div key={q.id} className='mb-6 border p-4 rounded shadow'>
          <p className='mb-2 font-semibold'>{q.enunciado}</p>
          {["a", "b", "c", "d", "e"].map(letra => q[`alternativa_${letra}`] && (
            <button
              key={letra}
              className={`block text-left w-full p-2 rounded mb-1 border hover:bg-blue-100 ${respostas[q.id] === letra ? 'bg-blue-200' : ''}`}
              onClick={() => responder(q.id, letra)}>
              <strong>{letra.toUpperCase()})</strong> {q[`alternativa_${letra}`]}
            </button>
          ))}
        </div>
      ))}
    </div>
  );
}

function App() {
  const [token, setToken] = useState(localStorage.getItem('token'));

  return (
    <Router>
      <Toaster />
      <Routes>
        <Route path='/' element={token ? <Questoes /> : <Navigate to='/login' />} />
        <Route path='/login' element={<Login setToken={setToken} />} />
      </Routes>
    </Router>
  );
}

export default App;